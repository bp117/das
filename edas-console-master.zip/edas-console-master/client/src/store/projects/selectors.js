export const getState = state => state.projects;
