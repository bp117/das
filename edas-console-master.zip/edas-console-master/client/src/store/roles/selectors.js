export const getState = state => state.roles;
