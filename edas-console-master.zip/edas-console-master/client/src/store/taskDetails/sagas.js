import { put, takeLatest, call, all } from 'redux-saga/effects';
import * as TYPES from './types';
import { 
    taskdetailsApi, 
    singleTaskdetailApi, 
    editTaskdetailApi, 
    deleteTaskdetailApi, 
    editMultipleTasksApi,
    utteranceLabelApi,
    utterancesApi,
    addTaskdetailApi
 } from './api';

function* taskdetails(payload) {
    try {
        const response = yield call(taskdetailsApi, payload.payload);
        yield put({
            type: TYPES.TASKDETAILS_SUCCESS,
            payload: response,
        });
    } catch (error) {
        yield put({
            type: TYPES.TASKDETAILS_FAILED,
            error: error && error.message,
        });
    }
}

function* singleTaskdetail(payload) {
    try {
        const response = yield call(singleTaskdetailApi, payload.payload);
        yield put({
            type: TYPES.SINGLE_TASKDETAIL_SUCCESS,
            payload: response,
        });
    } catch (error) {
        yield put({
            type: TYPES.SINGLE_TASKDETAIL_FAILED,
            error: error && error.message,
        });
    }
}

function* editTaskdetail(payload) {
    try {
        const allTaskDetails = yield call(taskdetailsApi);
        let response;
        if(Array.isArray(allTaskDetails)){
            const matches = allTaskDetails.filter(el => el.utterance_id === payload.payload.meta.system_utterance_id);
            if(matches.length > 0){
                const match = matches[matches.length-1];
                response = yield call(editTaskdetailApi, {id: match.id, data: payload.payload.data});
            }
            else {
                response = yield call(addTaskdetailApi, {
                    data: {
                        ...payload.payload.data,
                        utterance_id: payload.payload.meta.system_utterance_id
                    }
                });
            }
        }
        yield put({
            type: TYPES.EDIT_TASKDETAIL_SUCCESS,
            payload: response,
        });
        const updatedAllTaskDetails = yield call(taskdetailsApi);
        yield put({
            type: TYPES.TASKDETAILS_SUCCESS,
            payload: updatedAllTaskDetails,
        });
        
    } catch (error) {
        yield put({
            type: TYPES.EDIT_TASKDETAIL_FAILED,
            error: error && error.message,
        });
    }
}

function* editMultipleTasksdetail(payload) {
    try {
        const allTaskDetails = yield call(taskdetailsApi);
        const label = payload.payload.label;
        const modifiedRequest = payload.payload.ids.map(p => {
            const matches = allTaskDetails.filter(el => el.utterance_id === p.meta.system_utterance_id);
            if(matches.length > 0){
                return {
                    id: matches[matches.length-1].id,
                    data: {
                        label_id: label
                    }
                }
            }
            else{
                return {
                    data: {
                        label_id: label,
                        utterance_id: p.meta.system_utterance_id
                    }
                }
            }
        });

        const response = yield call(editMultipleTasksApi, modifiedRequest);
        yield put({
            type: TYPES.EDITMULTIPLE_TASKDETAIL_SUCCESS,
            payload: response,
        });
        const updatedAllTaskDetails = yield call(taskdetailsApi);
        yield put({
            type: TYPES.TASKDETAILS_SUCCESS,
            payload: updatedAllTaskDetails,
        });
        
    } catch (error) {
        yield put({
            type: TYPES.EDITMULTIPLE_TASKDETAIL_FAILED,
            error: error && error.message,
        });
    }
}

function* deleteTaskdetail(payload) {
    try {
        const response = yield call(deleteTaskdetailApi, payload.payload);
        yield put({
            type: TYPES.DELETE_TASKDETAIL_SUCCESS,
            payload: response,
        });
        yield put({ type: TYPES.FETCH_TASKDETAILS});

    } catch (error) {
        yield put({
            type: TYPES.DELETE_TASKDETAIL_FAILED,
            error: error && error.message,
        });
    }
}

function* utterances(payload) {
    try {
        const response = yield call(utterancesApi, payload.payload);
        yield put({
            type: TYPES.UTTERANCES_SUCCESS,
            payload: response,
        });
    } catch (error) {
        yield put({
            type: TYPES.UTTERANCES_FAILED,
            error: error && error.message,
        });
    }
}

function* utteranceLabel(payload) {
    try {
        const response = yield call(utteranceLabelApi, payload.payload);
        yield put({
            type: TYPES.UTTERANCE_LABELS_SUCCESS,
            payload: response,
        });
    } catch (error) {
        yield put({
            type: TYPES.UTTERANCE_LABELS_FAILED,
            error: error && error.message,
        });
    }
}


export default function* taskdetailsSaga() {
    yield all([
        yield takeLatest(TYPES.FETCH_TASKDETAILS, taskdetails),
        yield takeLatest(TYPES.FETCH_SINGLE_TASKDETAIL, singleTaskdetail),
        yield takeLatest(TYPES.EDIT_TASKDETAIL, editTaskdetail),
        yield takeLatest(TYPES.DELETE_TASKDETAIL, deleteTaskdetail),
        yield takeLatest(TYPES.FETCH_UTTERANCES, utterances),
        yield takeLatest(TYPES.FETCH_UTTERANCE_LABELS, utteranceLabel),
        yield takeLatest(TYPES.EDITMULTIPLE_TASKDETAIL, editMultipleTasksdetail)
    ])
}