export const getState = state => state.taskDetails;
