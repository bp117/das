import * as TYPES from './types';

export const fetchTaskDetails = (payload) => ({
    type: TYPES.FETCH_TASKDETAILS,
    payload
});

export const clearTaskDetails = () => ({
    type: TYPES.CLEAR_TASKDETAILS
});

export const fetchSingleTaskDetail = (payload) => ({
    type: TYPES.FETCH_SINGLE_TASKDETAIL,
    payload
});

export const clearSingleTaskDetail = () => ({
    type: TYPES.CLEAR_SINGLE_TASKDETAIL
});

export const editTaskDetail = (payload) => ({
    type: TYPES.EDIT_TASKDETAIL,
    payload
});

export const clearEditTaskDetail = () => ({
    type: TYPES.CLEAR_EDIT_TASKDETAIL
})

export const deleteTaskDetail = (payload) => ({
    type: TYPES.DELETE_TASKDETAIL,
    payload
});

export const clearDeleteTaskDetail = () => ({
    type: TYPES.CLEAR_DELETE_TASKDETAIL
})

export const editMultipleTasks = (payload) => ({
    type: TYPES.EDITMULTIPLE_TASKDETAIL,
    payload
});

export const clearEditMultipleTasks = () => ({
    type: TYPES.CLEAR_EDITMULTIPLE_TASKDETAIL
})

export const fetchUtterances = (payload) => ({
    type: TYPES.FETCH_UTTERANCES,
    payload
});

export const fetchUtteranceLabels = (payload) => ({
    type: TYPES.FETCH_UTTERANCE_LABELS,
    payload
});

export const clearUtterances = () => ({
    type: TYPES.CLEAR_UTTERANCES
});

export const clearUtterancesLabels = () => ({
    type: TYPES.CLEAR_UTTERANCE_LABELS
});