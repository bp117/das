import axios from 'axios';

export const taskdetailsApi = () => {
    return axios.get('/v1/api/task-details/')
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}

export const singleTaskdetailApi = (payload) => {
    return axios.get(`/v1/api/task-details/${payload.id}/`)
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}

export const editTaskdetailApi = (payload) => {
    return axios.patch(`/v1/api/task-details/${payload.id}/`, payload.data)
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}

export const deleteTaskdetailApi = (payload) => {
    return axios.delete(`/v1/api/task-details/${payload.id}/`)
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}

export const addTaskdetailApi = (payload) => {
    return axios.post(`/v1/api/task-details/`, payload.data)
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}

export const editMultipleTasksApi = (payload) => {
    console.log("API", payload);
    return Promise.all(
        payload.map(el => {
            if(el.id) {
                return axios.patch(`/v1/api/task-details/${el.id}/`, el.data);
            }
            else {
                return axios.post(`/v1/api/task-details/`, el.data)
            }
        })
    )
    .then(res => {
        return res.map(e => e.data);
    }).catch(error => {
        throw new Error(error.detail);
    });

}

export const utterancesApi = () => {
    return axios.get('https://jsonblob.com/api/9c305063-e716-11ea-bdf5-19155d636077')
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}

export const utteranceLabelApi = () => {
    return axios.get('https://jsonblob.com/api/b0d8b3da-e716-11ea-bdf5-e70981f78e4a')
    .then(res => {
        return res.data;
    }).catch(error => {
        throw new Error(error.detail);
    });
}