import { combineReducers } from 'redux';
import * as TYPES from './types';

const initialState = {
taskDetails: {
    data: null,
    loading: false,
    error: null,
},
};

const taskDetails = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.FETCH_TASKDETAILS:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.TASKDETAILS_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.TASKDETAILS_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_TASKDETAILS:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const singleTaskDetail = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.FETCH_SINGLE_TASKDETAIL:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.SINGLE_TASKDETAIL_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.SINGLE_TASKDETAIL_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_SINGLE_TASKDETAIL:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const editTaskDetail = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.EDIT_TASKDETAIL:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.EDIT_TASKDETAIL_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.EDIT_TASKDETAIL_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_EDIT_TASKDETAIL:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const deleteTaskDetail = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.DELETE_TASKDETAIL:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.DELETE_TASKDETAIL_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.DELETE_TASKDETAIL_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_DELETE_TASKDETAIL:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const editMultipleTaskDetails = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.EDITMULTIPLE_TASKDETAIL:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.EDITMULTIPLE_TASKDETAIL_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.EDITMULTIPLE_TASKDETAIL_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_EDITMULTIPLE_TASKDETAIL:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const utterances = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.FETCH_UTTERANCES:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.UTTERANCES_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.UTTERANCES_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_UTTERANCES:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const utteranceLabels = (state = {...initialState.taskDetails}, action) => {
    switch (action.type) {
        case TYPES.FETCH_UTTERANCE_LABELS:
            return { ...initialState.taskDetails, loading: true };
        case TYPES.UTTERANCE_LABELS_SUCCESS:
            return { ...state, loading: false, data: action.payload };
        case TYPES.UTTERANCE_LABELS_FAILED:
            return { ...state, loading: false, error: action.error };
        case TYPES.CLEAR_UTTERANCE_LABELS:
            return {...initialState.taskDetails};
        default:
            return state;
    }
};

const taskDetailsReducer = combineReducers({
    taskDetails,
    singleTaskDetail,
    editTaskDetail,
    deleteTaskDetail,
    editMultipleTaskDetails,
    utterances,
    utteranceLabels
});

export default taskDetailsReducer;