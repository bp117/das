import { combineReducers } from 'redux';
import users from './users';
import projects from './projects';
import roles from './roles';
import taskDetails from './taskDetails';
export default function createReducer() {
    return combineReducers({
        users,
        projects,
        roles,
        taskDetails
    })
}