import { connect } from 'react-redux';
import UserAdd from './UserAdd';
import { bindActionCreators } from '../../../utils/reducer';

import { 
    selectors as usersSelectors,
    actions as usersActions,
} from '../../../store/users';

const mapStateToProps = (state, props) => {
    return {
        userDetails: usersSelectors.getState(state),
        ...props
    }
};

const mapDispatchToProps = dispatch => ({
    usersActions: bindActionCreators(usersActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(UserAdd);