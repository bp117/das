import { connect } from 'react-redux';
import RoleAdd from './RoleAdd';
import { bindActionCreators } from '../../../utils/reducer';

import { 
    selectors as rolesSelectors,
    actions as rolesActions,
} from '../../../store/roles';

const mapStateToProps = (state, props) => {
    return {
        roleDetails: rolesSelectors.getState(state),
        ...props
    }
};

const mapDispatchToProps = dispatch => ({
    rolesActions: bindActionCreators(rolesActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(RoleAdd);