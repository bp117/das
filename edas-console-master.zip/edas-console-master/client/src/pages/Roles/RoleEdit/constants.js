export const COLUMNS = [
    {
        name: 'ID',
        selector: 'id'
    },
    {
        name: 'Role ID',
        selector: 'role_id'
    },
    {
        name: 'Role Desc',
        selector: 'role_desc'
    },
    {
        name: 'LOB ID',
        selector: 'lob_id'
    },
    {
        name: 'WFGroup ID',
        selector: 'wfgroup_id'
    },
]