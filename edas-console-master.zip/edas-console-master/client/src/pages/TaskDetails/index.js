import { connect } from 'react-redux';
import TaskDetails from './TaskDetails';
import { bindActionCreators } from '../../utils/reducer';

import { 
    selectors as tasksSelectors,
    actions as tasksActions,
} from '../../store/taskDetails';

const mapStateToProps = (state) => {
    return {
        taskDetails: tasksSelectors.getState(state)
    }
};

const mapDispatchToProps = dispatch => ({
    tasksActions: bindActionCreators(tasksActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(TaskDetails);