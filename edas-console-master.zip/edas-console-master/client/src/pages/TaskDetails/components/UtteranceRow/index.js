import React, {useState, useEffect} from 'react';

import { 
    makeStyles, 
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    TextField,
    IconButton,
    Collapse,
    Button,
    Drawer,
    Typography,
    Grid,
    Checkbox
} from '@material-ui/core';

import {
    ToggleButtonGroup,
    ToggleButton
} from '@material-ui/lab';

import {
    Check as CheckIcon,
    KeyboardArrowDown as KeyboardArrowDownIcon,
    KeyboardArrowUp as KeyboardArrowUpIcon,
    OpenInNew as OpenInNewIcon,
    Close as CloseIcon,
    Flag as FlagIcon,
    Subject as SubjectIcon,
    SpeakerNotes as SpeakerNotesIcon
} from '@material-ui/icons'

import Autocomplete from '@material-ui/lab/Autocomplete';

import './style.scss';

const DrawerItem = (props) => {
    const {
        label,
        value
    } = props;

    return (
        <div className="utterance-drawer-item">
            <div className="utterance-drawer-item-label">{label}</div>
            <div className="utterance-drawer-item-value">{value ? value : "-"}</div>
        </div>
    )
}

const UtteranceRow = (props) => {

    const {
        data,
        utteranceLabels,
        isUtteranceVisible,
        setUtteranceVisibility,
        index,
        taskDetails,
        isRowExpanded,
        setExapandedRowId,
        isDrawerOpen,
        setOpenDrawerRowId,
        editTask,
        searchString,
        isSelected,
        setSelectedRows,
        isDrawerPersistent
    } = props;

    const allFlags = [
        "flag_1",
        "flag_2",
        "flag_3",
        "flag_4",
        "flag_5"
    ];

    const SYSTEM_UTTERANCE_ID = data.sys_utter_id;
    const [currTaskDetails, setCurrTaskDetails] = useState({});
    const [value, setValue] = useState(null);
    const [flags, setFlags] = useState([]);
    const [notes, setNotes] = useState('');
    const [notesFromAPI, setNotesFromAPI] = useState('');
  

    useEffect(() => {
        const allCurrentTaskDetails = taskDetails.data.filter(el => el.utterance_id === SYSTEM_UTTERANCE_ID);
        
        if(allCurrentTaskDetails.length > 0){
            const currentTaskDetails = allCurrentTaskDetails[allCurrentTaskDetails.length - 1];
            
            setCurrTaskDetails(currentTaskDetails);
            setNotes(currentTaskDetails.notes);
            setNotesFromAPI(currentTaskDetails.notes);
            setFlags(allFlags.filter(f => currentTaskDetails[f]));

            if(currentTaskDetails.label_id){
                utteranceLabels.data.forEach(el => {
                    if(el.Label_id === currentTaskDetails.label_id){
                        setValue(el);
                    }
                });
            }
        }

    }, [taskDetails, utteranceLabels])

    const handleFlags = (event, newFlags) => {
        setFlags(newFlags);
        handleFlagsPush(newFlags);
    };

    const handleNotes = (val) => {
        setNotes(val);
    }

    const handleNotesPush = () => {
        const payload = {
            meta: {
                system_utterance_id: SYSTEM_UTTERANCE_ID
            },
            data: {
                notes
            }
        }
        editTask(payload);
    }

    const handleFlagsPush = (flags) => {
        const obj = {};
        allFlags.forEach((f) => {
            if(flags.includes(f)){
                obj[f] = true;
            }
            else{
                obj[f] = false;
            }
        });
        const payload = {
            meta: {
                system_utterance_id: SYSTEM_UTTERANCE_ID
            },
            data: {
                ...obj,
                notes
            }
        }
        editTask(payload);
    }

    const handleLabelPush = () => {
        const payload = {
            meta: {
                system_utterance_id: SYSTEM_UTTERANCE_ID
            },
            data: {
                label_id: value.Label_id
            }
        }
        editTask(payload);
    }

    const handleRowSelect = (e) => {
        const isChecked = e.target.checked;
        setSelectedRows(s => {
            if(isChecked){
                return [...s, index];
            }
            else {
                return s.filter(el => el!==index);
            }
        })
    }

    const handleExpandedRow = () => {
        setExapandedRowId(i => i === index ? null : index);
        if(isDrawerPersistent){
            setOpenDrawerRowId(i => i === index ? null : index);
        }
    }

    const handleDrawerClose = () => {
        setOpenDrawerRowId(null);
        if(isDrawerPersistent){
            setExapandedRowId(null);
        }
    }

    return (
        <>
            <TableRow className="utterance-row">
                <TableCell>
                    <Checkbox
                        checked={isSelected}
                        onChange={handleRowSelect}
                        color="primary"
                        inputProps={{ 'aria-label': 'primary checkbox' }}
                    />
                </TableCell>
                <TableCell>
                    <span dangerouslySetInnerHTML={{__html: data.ds_id.toString().replace(searchString, `<span class="highlighted-utterance">${searchString}</span>`)}} />
                </TableCell>
                <TableCell>
                    <span dangerouslySetInnerHTML={{__html: data.user_utter_id.toString().replace(searchString, `<span class="highlighted-utterance">${searchString}</span>`)}} />
                </TableCell>
                <TableCell>
                    <span className={`utterance-text ${isUtteranceVisible ? 'selected-utterance' : ''}`} onClick={() => setUtteranceVisibility(i => i === index ? null : index)}>
                        <span dangerouslySetInnerHTML={{__html: data.utterence_content.replace(searchString, `<span class="highlighted-utterance">${searchString}</span>`)}} />
                    </span>
                    
                        {
                            isUtteranceVisible && utteranceLabels.data && (
                                <div className="mt-15 utterance-label-input-container">
                                    <Autocomplete
                                        id="combo-box-demo"
                                        value={value}
                                        onChange={(event, newValue) => {
                                            setValue(newValue);
                                        }}
                                        options={utteranceLabels.data}
                                        getOptionLabel={(option) => option.label_title}
                                        style={{ width: 300 }}
                                        renderInput={(params) => <TextField {...params} label="Enter label" variant="outlined" size="small" />}
                                    />

                                    {
                                        value && <IconButton color="primary" aria-label="Update Label" className="update-label-button" onClick={handleLabelPush}>
                                            <CheckIcon />
                                        </IconButton>
                                    }

                                </div>
                            )
                        }
                        
                </TableCell>
                <TableCell align="right">
                    
                    {notesFromAPI && <SpeakerNotesIcon color="primary" />}

                    {' '}
                    
                    {flags.length > 0 && <FlagIcon color="error" className="ml-12" />}
                    
                    <IconButton onClick={handleExpandedRow} color="primary" aria-label="Update Flags" className="update-label-button">
                        { isRowExpanded ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon /> }
                    </IconButton>

                    {' '}
                    
                    {
                        !isDrawerPersistent && <IconButton onClick={() => setOpenDrawerRowId(i => i === index ? null : index)} color="primary" aria-label="Open Drawer" className="update-label-button">
                            <OpenInNewIcon />
                        </IconButton>
                    }

                </TableCell>
            </TableRow>
            <TableRow>
                <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={5}>
                    <Collapse in={isRowExpanded} timeout="auto" unmountOnExit>
                        <div className="expanded-row-container">
                            
                            <TextField
                                label="Enter notes here"
                                multiline
                                rows={3}
                                variant="outlined"
                                className="utterance-row-notes-textarea"
                                value={notes}
                                onChange={(e) => handleNotes(e.target.value)}
                                onBlur={handleNotesPush}
                            />
                            
                            <ToggleButtonGroup size="small" value={flags} onChange={handleFlags} aria-label="Toggle flags">
                                <ToggleButton 
                                    value="flag_1" 
                                    aria-label="Unusable"
                                    >
                                    <FlagIcon />
                                    Unusable
                                </ToggleButton>
                                <ToggleButton value="flag_2" aria-label="Review">
                                    <FlagIcon />
                                    Review
                                </ToggleButton>
                                <ToggleButton value="flag_3" aria-label="Reassign">
                                    <FlagIcon />
                                    Reassign
                                </ToggleButton>
                            </ToggleButtonGroup>
                        </div>
                    </Collapse>
                </TableCell>
            </TableRow>

            <Drawer 
                anchor="right"  
                open={isDrawerOpen} 
                variant={isDrawerPersistent ? "persistent" : "temporary"}
                onClose={() => setOpenDrawerRowId(null)}>

                <Grid container className={`utterance-drawer-container ${isDrawerPersistent ? 'persisten-drawer' : ''}`}>
                    <Grid container direction="row" justify="space-between" className="utterance-drawer-container-header">
                        <Typography component="h3" variant="h4" color="primary" gutterBottom>
                            Utterance Details
                        </Typography>
                        <div>
                            <IconButton onClick={handleDrawerClose} color="primary" aria-label="Close Drawer">
                                <CloseIcon />
                            </IconButton>
                        </div>
                    </Grid>

                    <Grid container direction="column" className="utterance-drawer-item-container">
                        <DrawerItem label="Utterance" value={data.utterence_content} />
                        <DrawerItem label="Source Intent" value={data.source_intent} />
                        <DrawerItem label="Confidence Score" value={data.confidence_score} />
                        <DrawerItem label="Model ID" value={data.project_id} />
                        <DrawerItem label="Date / Time" value={data.usr_dttm_pst} />
                        <DrawerItem label="Data Source" value={data.ds_id} />

                        <div className="mt-20">

                            <TextField
                                label="Enter notes here"
                                multiline
                                rows={4}
                                variant="outlined"
                                className="utterance-notes-textarea"
                                value={notes}
                                onChange={(e) => handleNotes(e.target.value)}
                                onBlur={handleNotesPush}
                            />
                            
                            <div className="mt-20">
                                <ToggleButtonGroup size="small" value={flags} onChange={handleFlags} aria-label="Toggle flags">
                                    <ToggleButton value="flag_1" aria-label="Unusable">
                                        <FlagIcon />
                                        Unusable
                                    </ToggleButton>
                                    <ToggleButton value="flag_2" aria-label="Review">
                                        <FlagIcon />
                                        Review
                                    </ToggleButton>
                                    <ToggleButton value="flag_3" aria-label="Reassign">
                                        <FlagIcon />
                                        Reassign
                                    </ToggleButton>
                                </ToggleButtonGroup>
                            </div>
                        </div>
                    </Grid>
                </Grid>
            </Drawer>
        </>
    )
};

export default UtteranceRow;