import React, {useState, useEffect} from 'react';
// import 'date-fns';
import {
    makeStyles,
    TextField,
    Button,
    Typography,
    InputAdornment,
    IconButton
} from '@material-ui/core';

import {
    Close as CloseIcon
} from '@material-ui/icons';

// import {
//     MuiPickersUtilsProvider,
//     KeyboardTimePicker,
//     KeyboardDatePicker,
// } from '@material-ui/pickers';
// import DateFnsUtils from '@date-io/date-fns';


import {
    Modal
} from '../../../../components';

import './style.scss';

const useStyles = makeStyles((theme) => ({
    buttonContainer: {
        margin: theme.spacing(2),
        marginTop: '30px',
        textAlign: 'right'
    }
}))

const FiltersContainer = (props) => {
    const classes = useStyles();
    const {
        setFilters
    } = props;

    const [searchInternal, setSearchInternal] = useState("");
    const [dateInternal, setDateInternal] = useState('')
    const [datePassed, setDatePassed] = useState('')

    const [isModalOpen, toggleModal] = useState(false);

    useEffect(() => {
        setFilters({
            ...getAllFilters()
        })
    }, [datePassed])

    const getAllFilters = () => {
        return {
            utterence_content: searchInternal,
            usr_dttm_pst: datePassed
        }
    }

    const handles = {
        search: (e) => {
            if(e.keyCode === 13) {
                setFilters({
                    ...getAllFilters()
                })
            }
        },
        advancedFiltersCancel: () => {
            setDateInternal(datePassed);
            toggleModal(false)
        },

        advancedFiltersSubmit: (e) => {
            e.preventDefault();
            setDatePassed(dateInternal);
            toggleModal(false)
        },
        advancedFiltersClear: (e) => {
            setDateInternal('');
            setDatePassed('');
            toggleModal(false);
        }
    };

    return (
        <>
            <div className="filters-comp-container">
                <TextField
                    label="Search"
                    variant="outlined"
                    value={searchInternal}
                    onChange={(e) => setSearchInternal(e.target.value)}
                    onKeyUp={handles.search}
                    size="small"
                    className="filters-comp-container-search"
                    // InputProps={{
                    //     endAdornment: (
                    //       <InputAdornment>
                    //         <IconButton size="small" onClick={handles.searchClose}>
                    //           <CloseIcon />
                    //         </IconButton>
                    //       </InputAdornment>
                    //     )
                    //   }}
                />
                
                <Button variant="contained" color="primary" onClick={() => toggleModal(true)}>
                    Advanced Filters
                </Button>
            </div>

            <Modal 
                open={isModalOpen} 
                disableBackdropClick={false}
                handleClose={() => toggleModal(false)}>
                
                <>
                    <Typography component="h1" variant="h4" color="primary" gutterBottom>
                        Advanced Filters
                    </Typography>

                    <form className="mt-20" onSubmit={handles.advancedFiltersSubmit}>
                        <div className="mt-40">
                            <TextField
                                type="date"
                                variant="outlined"
                                value={dateInternal}
                                onChange={(e) => setDateInternal(e.target.value)}
                                size="small"
                            />
                            {/* <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    margin="normal"
                                    id="date-picker-inline"
                                    label="Date picker inline"
                                    value={dateInternal}
                                    onChange={setDateInternal}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider> */}
                        </div>

                        <div className={classes.buttonContainer}>
                            <Button type="submit" variant="contained" color="primary">
                                Apply Filters
                            </Button>
                            {' '}
                            <Button type="button" variant="contained" onClick={handles.advancedFiltersClear}>
                                Clear Filters
                            </Button>
                            {' '}
                            <Button type="button" variant="contained" onClick={handles.advancedFiltersCancel}>
                                Cancel
                            </Button>
                        </div>
                    </form>
                    
                </>

            </Modal>
        </>
    )
    
};

export default FiltersContainer;