import React, {useState, useEffect} from 'react';
import {
    makeStyles,
    IconButton,
    Button
} from '@material-ui/core';

import {
    Add as AddIcon,
    Remove as MinusIcon
} from '@material-ui/icons';
import './style.scss';

const useStyles = makeStyles((theme) => ({
    button: {
        margin: '0 10px'
    }
}));

const FrequentLabels = (props) => {
    const classes = useStyles();
    const [showAllLabels, setShowAllLabels] = useState(false);
    const {
        utteranceLabels: {
            data: utteranceLabelArray
        },
        selectedRows,
        editMultipleTasks,
        utterances
    } = props;

    if(!Array.isArray(utteranceLabelArray) || utteranceLabelArray.length === 0){
        return null;
    }

    const multipleEditHandler = (id) => {
        const selectedUtterances = utterances.data.filter((el, i) => selectedRows.includes(i));
        const payload = selectedUtterances.map(el => ({
            meta: {
                system_utterance_id: el.sys_utter_id,
            }
        }));

        editMultipleTasks({
            ids: payload,
            label: id
        })
    }

    return (
        <div className="frequent-utterance-label">
            {
                (showAllLabels ? utteranceLabelArray : utteranceLabelArray.slice(0,5)).map(u => (
                    <div key={u.Label_id} className="frequent-utterance-label-item">
                        <Button 
                            variant="contained" 
                            color="primary"
                            onClick={() => multipleEditHandler(u.Label_id)} 
                            disabled={selectedRows.length === 0}>
                                {u.label_title}
                        </Button>
                        {' '}
                    </div>
                ))
            }
            <IconButton aria-label="delete" className={classes.button} onClick={() => setShowAllLabels(t => !t)}>
                { !showAllLabels ? <AddIcon /> : <MinusIcon /> }
            </IconButton>
        </div>
    )
};

export default FrequentLabels;