import React, {useEffect, useState, useMemo} from 'react';

import { 
    makeStyles, 
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    TableSortLabel,
    Grid,
    Typography,
    TablePagination
} from '@material-ui/core';

import {
    Alert
} from '@material-ui/lab';

import {
    get,
    isEmpty
} from 'lodash';

import { useSnackbar } from 'notistack';

import {
    Loader
} from '../../components';

import UtteranceRow from './components/UtteranceRow';
import FrequentLabels from './components/FrequentLabels';
import FiltersContainer from './components/FiltersContainer';

const drawerWidth = 400;
const useStyles = makeStyles((theme) => ({
    table: {
      minWidth: 650,
    },
    appBar: {
        transition: theme.transitions.create(['margin', 'width'], {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.leavingScreen,
        }),
    },
    appBarShift: {
        width: `calc(100% - ${drawerWidth}px)`,
        marginRight: drawerWidth,
        transition: theme.transitions.create(['margin', 'width'], {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
}));

const TaskDetails = (props) => {

    const [visibleUtteranceLabelId, setVisibleUtteranceLabelId] = useState(null);
    const [expandedRowId, setExapandedRowId] = useState(null);
    const [openDrawerRowId, setOpenDrawerRowId] = useState(null);
    const [allFilters, setAllFilters] = useState({});
    const [orderBy, setOrderBy] = useState(null);
    const [order, setOrder] = useState(null);
    const [selectedRows, setSelectedRows] = useState([]);
    const [isDrawerPersistent, setIsDrawerPersistent] = useState(false);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const { enqueueSnackbar, closeSnackbar } = useSnackbar();

    const classes = useStyles();

    const {
        taskDetails:{
            taskDetails,
            singleTaskDetail,
            editTaskDetail,
            deleteTaskDetail,
            editMultipleTaskDetails,
            utterances,
            utteranceLabels
        },
        tasksActions: {
            fetchTaskDetails,
            clearTaskDetails,
            fetchSingleTaskDetail,
            clearSingleTaskDetail,
            editTaskDetail: editTask,
            clearEditTaskDetail,
            deleteTaskDetail: deleteTask,
            clearDeleteTaskDetail,
            editMultipleTasks,
            clearEditMultipleTasks,
            fetchUtterances,
            clearUtterances,
            fetchUtteranceLabels,
            clearUtterancesLabels,
        }
    } = props;

    useEffect(() => {
        fetchTaskDetails();
        fetchUtterances();
        fetchUtteranceLabels();

        return () => {
            clearUtterances();
            clearUtterancesLabels();
            clearTaskDetails();
            clearEditTaskDetail();
        }
    }, []);

    const resetAllSelections = () => {
        setOpenDrawerRowId(null);
        setExapandedRowId(null);
        setVisibleUtteranceLabelId(null);
        setSelectedRows([]);
    }

    useEffect(() => {
        if(!isEmpty(editTaskDetail.data)){
            enqueueSnackbar("Utterance updated successfully")
        }
    }, [editTaskDetail]);

    useEffect(() => {
        if(!isEmpty(editMultipleTaskDetails.data)){
            enqueueSnackbar(`${editMultipleTaskDetails.data.length} utterances updated successfully`);
            setSelectedRows([]);
        }
    }, [editMultipleTaskDetails]);

    useEffect(() => {
        resetAllSelections();
    }, [allFilters, orderBy, order])

    const isLoading = React.useMemo(() => {
        return utterances.loading || taskDetails.loading || utteranceLabels.loading;
    }, [utterances, taskDetails, utteranceLabels])

    const isData = React.useMemo(() => {
        return utterances.data && taskDetails.data && utteranceLabels.data;
    }, [utterances, taskDetails, utteranceLabels]);

    const isError = React.useMemo(() => {
        return utterances.error || taskDetails.error || utteranceLabels.error;
    }, [utterances, taskDetails, utteranceLabels]);

    const filteredUtterances = useMemo(() => {
        if(!Array.isArray(utterances.data)) return null;

        const filteredData = utterances.data.filter(u => {
            var isTaken = true;

            if(!isEmpty(allFilters.utterence_content)){
                if(
                    u.utterence_content.indexOf(allFilters.utterence_content) === -1
                    && u.ds_id.toString().indexOf(allFilters.utterence_content) === -1
                    && u.user_utter_id.toString().indexOf(allFilters.utterence_content) === -1
                    ){
                    isTaken = false;
                }
            }

            if(!isEmpty(allFilters.usr_dttm_pst)){
                if(!u.usr_dttm_pst || u.usr_dttm_pst.indexOf(allFilters.usr_dttm_pst) === -1) {
                    isTaken = false;
                }
            }

            return isTaken;
        });

        if(!orderBy) {
            return filteredData;
        }

        return filteredData.sort((a, b) => {
            if(order === "asc"){
                return a[orderBy] > b[orderBy] ? 1 : -1;
            }
            return a[orderBy] > b[orderBy] ? -1 : 1; 
        })

    }, [utterances, allFilters, order, orderBy]);

    const createSortHandler = (id) => {
        setOrderBy(id);
        setOrder(o => o === "asc" ? "desc" : "asc");
    }

    const COLUMNS = [
        {
            id: "ds_id",
            label: "UID"
        },
        {
            id: "user_utter_id",
            label: "Author"
        },
        {
            id: "utterence_content",
            label: "Utterance"
        }
    ];

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
        resetAllSelections();
    }
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
        resetAllSelections();
    };

    return (
        <div className={`${isDrawerPersistent ? classes.appBar : ''} ${ isDrawerPersistent && openDrawerRowId !== null ? classes.appBarShift : ''}`}>

            {
                isLoading && <Loader />
            }

            {
                isError && (
                    <Alert severity="error" onClose={clearUtterances}>Unable to fetch utterances! Something went wrong.</Alert>
                )
            }

            {
                isData && (
                    <div>
                        <Grid container direction="row" justify="space-between">
                            <Typography component="h1" variant="h4" color="primary" gutterBottom>
                                My Tasks
                            </Typography>
                            <FiltersContainer setFilters={setAllFilters} />
                        </Grid>
                        <div>
                            
                        </div>
                        <div className="mt-30">
                            <FrequentLabels 
                                utteranceLabels={utteranceLabels}
                                selectedRows={selectedRows}
                                editMultipleTasks={editMultipleTasks}
                                utterances={utterances} />
                        </div>
                        <TableContainer component={Paper} className="mt-30">
                            <Table className={classes.table} aria-label="simple table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell />
                                        
                                        {
                                            COLUMNS.map(headCell => (
                                                <TableCell
                                                    key={headCell.id}
                                                    sortDirection={orderBy === headCell.id ? order : false}
                                                >
                                                    <TableSortLabel
                                                    active={orderBy === headCell.id}
                                                    direction={orderBy === headCell.id ? order : 'asc'}
                                                    onClick={() => createSortHandler(headCell.id)}
                                                    >
                                                    {headCell.label}
                                                    </TableSortLabel>
                                                </TableCell>
                                            ))
                                        }
                                        
                                        <TableCell align="right"></TableCell>
                                    </TableRow>
                                </TableHead>

                                <TableBody>
                                    {
                                        filteredUtterances
                                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                        .map((d, index) => (
                                            <UtteranceRow 
                                                index={index}
                                                data={d} 
                                                key={d.sys_utter_id}
                                                taskDetails={taskDetails}
                                                utteranceLabels={utteranceLabels}
                                                isUtteranceVisible={visibleUtteranceLabelId === index}
                                                setUtteranceVisibility={setVisibleUtteranceLabelId}
                                                isRowExpanded={expandedRowId === index}
                                                setExapandedRowId={setExapandedRowId}
                                                isDrawerOpen={openDrawerRowId === index}
                                                setOpenDrawerRowId={setOpenDrawerRowId}
                                                editTask={editTask}
                                                searchString={allFilters.utterence_content}
                                                isSelected={selectedRows.includes(index)}
                                                setSelectedRows={setSelectedRows}
                                                isDrawerPersistent={isDrawerPersistent} />
                                        ))
                                    }
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            rowsPerPageOptions={[10, 25, 50, 100]}
                            rowsPerPage={rowsPerPage}
                            component="div"
                            count={filteredUtterances.length}
                            page={page}
                            onChangePage={handleChangePage}
                            onChangeRowsPerPage={handleChangeRowsPerPage}
                        />
                    </div>
                )
            }

        </div>
    )
};

export default TaskDetails;