# EDAS Console

Repository for EDAS Console

For development and deployment, check readme.md of parent directory.