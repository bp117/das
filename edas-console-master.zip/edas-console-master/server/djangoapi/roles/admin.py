from django.contrib import admin
from .models import Roles

admin.site.register(Roles)
# Register your models here.
