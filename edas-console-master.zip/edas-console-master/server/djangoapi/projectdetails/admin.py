from django.contrib import admin
from .models import ProjectDetails

admin.site.register(ProjectDetails)