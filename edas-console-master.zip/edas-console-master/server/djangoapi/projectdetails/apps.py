from django.apps import AppConfig


class ProjectdetailsConfig(AppConfig):
    name = 'projectdetails'
