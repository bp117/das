from rest_framework import serializers
from .models import TaskDetails

class TaskDetailsSerializers(serializers.ModelSerializer):
    class Meta:
        model = TaskDetails
        fields = ('id',
                  'utterance_id',
                  'label_id',
                  'notes',
                  'flag_1',
                  'flag_2',
                  'flag_3',
                  'flag_4',
                  'flag_5')
        extra_kwargs = {
            'notes': {
                'required': False,
                'allow_blank': True,
            },
            'label_id': {
                'required': False
            }
        }