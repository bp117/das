from django.apps import AppConfig


class TaskdetailsConfig(AppConfig):
    name = 'taskDetails'
