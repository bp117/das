from django.shortcuts import render
from rest_framework import viewsets
from .models import TaskDetails
from .serializers import TaskDetailsSerializers

class TaskDetailsView(viewsets.ModelViewSet):
    queryset = TaskDetails.objects.all()
    serializer_class = TaskDetailsSerializers
