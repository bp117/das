from django.db import models

class TaskDetails(models.Model):
    utterance_id = models.CharField(max_length=100, default="")
    notes = models.CharField(max_length=5000, default="")
    label_id = models.IntegerField(blank=True, null=True)
    flag_1 = models.BooleanField(default=False)
    flag_2 = models.BooleanField(default=False)
    flag_3 = models.BooleanField(default=False)
    flag_4 = models.BooleanField(default=False)
    flag_5 = models.BooleanField(default=False)

    def __str__(self):
        return self.utterance_id